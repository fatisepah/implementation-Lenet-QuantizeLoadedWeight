In many research projects (for example, in hardware projects) to perform a specific task (for example, changing the multiplication operation, obtaining the maximum and implementing different functions based on a new hardware), it is necessary to be able to convert the trained weights into integer numbers. and converted in a specific range of numbers (for example 8-bit numbers) so that the process of converting these weights into binary numbers in that specific range is easier. A special scale is written and after applying the desired operation on these numbers or this array, we return the array numbers to their previous state using the Dequantize function.
For example, in the convolution layer, to multiply the input by weight, we first quantize both of these arrays based on a scale, and then multiply based on the quantized numbers and then dequantize the desired output. And according to the test that has been done, the work of the functions is done correctly.


در بسیاری از پروژه های تحقیقاتی (مثلا در پروژه های سخت افزاری) برای انجام یک کار خاص 
(مثلا تغییر عملیات ضرب، بدست آوردن ماکزیمم و پیاده سازی توابع مختلف براساس یک سخت افزار جدید) نیاز است که بتوانیم وزنهای 
Train 
شده را به اعداد 
Integer 
و در یک محدوده خاصی از اعداد (مثلا اعداد 8 بیتی) تبدیل کرده که فرآیند تبدیل این وزنها به اعداد باینری 
موجود درآن رنج خاص راحت تر صورت گیرد، برای انجام این کار ابتدا تابعی
 را برای 
Quantize 
کردن اعداد کل آرایه ی داده شده براساس یک 
Scale 
خاص، نوشته شده و بعد از اعمال عملیات مورد نظر بر روی این اعداد و یا این آرایه، با استفاده از تابع 
Dequantize
، اعداد آرایه را به حالت قبلی برمیگردانیم.
مثلا در لایه ی
 Convolution 
برای ضرب 
input
 در 
Weight 
ابتدا هر دوی این آرایه ها را براساس یک 
Scale
، Quantize 
می کنیم و سپس ضرب را براساس اعداد 
Quantize 
شده انجام می دهیم و سپی خروجی مورد نظر را 
Dequantize 
می کنیم. و با توجه به تستی که انجام گرفته شده، کار توابع درست انجام می گیرد.
